// JavaScript is used to close the dropdown when clicking outside of it

document.addEventListener("DOMContentLoaded", function () {
    const dropdowns = document.querySelectorAll(".dropdown");

    dropdowns.forEach((dropdown) => {
        dropdown.addEventListener("click", function (event) {
            event.stopPropagation(); // Prevent the dropdown from closing immediately
        });

        document.addEventListener("click", function () {
            dropdown.querySelector(".dropdown-menu").style.display = "none";
        });

        dropdown.querySelector(".dropdown-menu").addEventListener("click", function (event) {
            event.stopPropagation(); // Prevent clicks inside the dropdown menu from closing it
        });
    });
});
function performSearch() {
    const searchTerm = document.getElementById('search-input').value;
    
    // Perform your search here using the 'searchTerm'
    // For this example, we'll just display an alert
    alert(`Searching for: ${searchTerm}`);
  }
  